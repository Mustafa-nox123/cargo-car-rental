// Compatibility wrapper: some tools expect a JS file named tailwind.config.js
// Re-export the CJS config to ensure Tailwind picks up the same settings.
// tailwind config removed. Leftover file kept temporarily but has no effect.
module.exports = {}

