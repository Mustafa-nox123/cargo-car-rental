// Tailwind removed from this project. Keep an empty export to avoid tooling errors.
module.exports = {}
