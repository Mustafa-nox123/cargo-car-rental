import React, { useState } from 'react'
import api from '../lib/api'
import adminApi from '../lib/adminApi'
import { useNavigate, useLocation, Link } from 'react-router-dom'
import { useAdminAuth } from '../context/AdminAuthContext'
import './auth.css'

export default function Login(){
  const [email,setEmail] = useState('')
  const [password,setPassword] = useState('')
  const [asAdmin,setAsAdmin] = useState(false)
  const [error,setError] = useState('')
  const [loading,setLoading] = useState(false)
  const nav = useNavigate()
  const location = useLocation()
  const isAdminPath = location.pathname.startsWith('/admin')
  const adminAuth = useAdminAuth()

  const submit = async e => {
    e.preventDefault()
    setError('')

    if(!email || !password){
      setError('Please enter email and password')
      return
    }

    setLoading(true)
    try {
      // decide admin vs customer login based on current path or the "Login as admin" checkbox
      const isAdmin = isAdminPath || asAdmin
      if(isAdmin){
        const res = await adminApi.post('/api/admin/login', { email, password })
        const token = res?.data?.token
        if(!token) throw new Error(res?.data?.error || 'No token returned')
        // store admin token via AdminAuthContext if available, otherwise fallback
        if(adminAuth && adminAuth.signIn) adminAuth.signIn(token)
        else localStorage.setItem('admin_token', token)
        nav('/admin/dashboard')
      } else {
        // use centralized axios instance (reads VITE_API_URL)
        const res = await api.post('/auth/login', { email, password })
        const token = res?.data?.token
        if(!token) throw new Error(res?.data?.error || 'No token returned')
        localStorage.setItem('token', token)
        // optional: store user if returned
        if(res.data.user) localStorage.setItem('user', JSON.stringify(res.data.user))
        // notify header/other components
        try { window.dispatchEvent(new Event('authChanged')) } catch(e){}
        nav('/dashboard')
      }
    } catch (err) {
      // prefer server-provided message
      const msg = err?.response?.data?.error || err?.response?.data?.message || err.message || 'Login failed'
      setError(msg)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="auth-page">
      <div className="auth-background"></div>
      <div className="auth-overlay"></div>
      
      <div className="auth-container">
        <div className="auth-card">
          <div className="auth-header">
            <div className="auth-logo">
              <span className="logo-car">Car</span>
              <span className="logo-go">Go</span>
            </div>
            <h1>Welcome Back</h1>
            <p>Sign in to manage your reservations</p>
          </div>

          {error && (
            <div className="auth-error">
              <span>⚠️</span> {error}
            </div>
          )}

          <form className="auth-form" onSubmit={submit}>
            <div className="form-group">
              <label>Email Address</label>
              <input
                type="email"
                value={email}
                onChange={e=>setEmail(e.target.value)}
                placeholder="you@example.com"
                required
              />
            </div>

            <div className="form-group">
              <label>Password</label>
              <input
                type="password"
                value={password}
                onChange={e=>setPassword(e.target.value)}
                placeholder="••••••••"
                required
              />
            </div>

            <div className="form-options">
              <label className="checkbox-label">
                <input 
                  type="checkbox" 
                  checked={asAdmin} 
                  onChange={e=>setAsAdmin(e.target.checked)} 
                />
                <span className="checkmark"></span>
                Login as Admin
              </label>
              <a href="/" className="forgot-link">Forgot password?</a>
            </div>

            <button type="submit" className="auth-btn" disabled={loading}>
              {loading && <span className="btn-spinner"></span>}
              {loading ? 'Signing in...' : 'Sign In'}
            </button>
          </form>

          <div className="auth-footer">
            <p>Don't have an account? <Link to="/register">Create one</Link></p>
          </div>
        </div>
      </div>
    </div>
  )
}
