import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import api from '../lib/api'
import './branches.css'

export default function Branches(){
  const [branches, setBranches] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    fetchBranches()
  }, [])

  const fetchBranches = async () => {
    try {
      setLoading(true)
      const res = await api.get('/branches')
      setBranches(res.data || [])
    } catch (err) {
      setError('Failed to load branches')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="branches-page">
      {/* Hero Section */}
      <div className="branches-hero">
        <div className="hero-content">
          <h1>📍 Our Locations</h1>
          <p>Find a CarGo branch near you for convenient pickup and drop-off</p>
        </div>
      </div>

      <div className="branches-container">
        {loading ? (
          <div className="loading-state">
            <div className="spinner"></div>
            <p>Loading branches...</p>
          </div>
        ) : error ? (
          <div className="error-state">
            <span>⚠️</span>
            <p>{error}</p>
          </div>
        ) : branches.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">📍</div>
            <h3>No Branches Found</h3>
            <p>Check back later for new locations.</p>
          </div>
        ) : (
          <div className="branches-grid">
            {branches.map(branch => (
              <div key={branch.branch_id} className="branch-card">
                <div className="branch-icon">
                  <span>🏢</span>
                </div>
                <div className="branch-content">
                  <h3>{branch.branch_name}</h3>
                  <div className="branch-details">
                    <div className="detail-row">
                      <span className="detail-icon">📍</span>
                      <span>{branch.city}</span>
                    </div>
                    {branch.address && (
                      <div className="detail-row">
                        <span className="detail-icon">🏠</span>
                        <span>{branch.address}</span>
                      </div>
                    )}
                    {branch.phone_no && (
                      <div className="detail-row">
                        <span className="detail-icon">📞</span>
                        <span>{branch.phone_no}</span>
                      </div>
                    )}
                  </div>
                </div>
                <Link to="/vehicles" className="branch-cta">
                  View Available Vehicles →
                </Link>
              </div>
            ))}
          </div>
        )}

        {/* CTA Section */}
        <div className="branches-cta-section">
          <h2>Ready to Book?</h2>
          <p>Browse our vehicles and make a reservation today</p>
          <Link to="/vehicles" className="btn-browse">
            🚗 Browse All Vehicles
          </Link>
        </div>
      </div>
    </div>
  )
}
