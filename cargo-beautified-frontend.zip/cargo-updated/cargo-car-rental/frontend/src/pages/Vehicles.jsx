import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import api from '../lib/api'
import './vehicles.css'

export default function Vehicles(){
  const [vehicleTypes, setVehicleTypes] = useState([])
  const [branches, setBranches] = useState([])
  const [filters, setFilters] = useState({ vehicle_type_id:'', branch_id:'', start_date:'', end_date:'' })
  const [vehicles, setVehicles] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [selectedVehicle, setSelectedVehicle] = useState(null)
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const navigate = useNavigate()

  useEffect(()=>{
    // Check if user is logged in
    const token = localStorage.getItem('token')
    setIsLoggedIn(!!token)
    
    // load vehicle types and branches for filter selects if available
    api.get('/vehicle-types').then(r=>setVehicleTypes(r.data)).catch(()=>{})
    api.get('/branches').then(r=>setBranches(r.data)).catch(()=>{})
  }, [])

  const buildQuery = () => {
    const params = new URLSearchParams()
    if(filters.vehicle_type_id) params.set('vehicle_type_id', filters.vehicle_type_id)
    if(filters.branch_id) params.set('branch_id', filters.branch_id)
    if(filters.start_date) params.set('start_date', filters.start_date)
    if(filters.end_date) params.set('end_date', filters.end_date)
    const s = params.toString()
    return s ? `?${s}` : ''
  }

  const fetchVehicles = async () => {
    setError('')
    setLoading(true)
    setVehicles([])
    try{
      const q = buildQuery()
      const res = await api.get(`/vehicles/available${q}`)
      console.log('Vehicles data:', res.data) // Debug log
      setVehicles(res.data || [])
    }catch(err){
      setError(err?.response?.data?.error || err?.message || 'Failed to fetch vehicles')
    }finally{
      setLoading(false)
    }
  }

  useEffect(()=>{ // initial fetch
    fetchVehicles()
  }, [])

  const onChange = e => {
    const { name, value } = e.target
    setFilters(f => ({ ...f, [name]: value }))
  }

  const onSubmit = e => {
    e.preventDefault()
    // basic validation: dates
    if(filters.start_date && filters.end_date && filters.start_date > filters.end_date){
      setError('Start date must be before or equal to end date.')
      return
    }
    fetchVehicles()
  }

  const reset = () => { setFilters({ vehicle_type_id:'', branch_id:'', start_date:'', end_date:'' }); setVehicles([]); setError(''); fetchVehicles() }

  const openVehicleModal = (vehicle) => {
    setSelectedVehicle(vehicle)
  }

  const closeModal = () => {
    setSelectedVehicle(null)
  }

  const handleReserve = () => {
    if(!isLoggedIn) {
      navigate('/login')
      return
    }
    // Navigate to reservation page with vehicle data
    navigate('/reservation', { 
      state: { 
        vehicle: selectedVehicle,
        branches: branches
      } 
    })
  }

  // Get full image URL
  const getImageUrl = (imageUrl) => {
    if (!imageUrl) return null
    // If it already starts with http, return as is
    if (imageUrl.startsWith('http')) return imageUrl
    // Otherwise prepend the server URL
    return `http://localhost:5000${imageUrl}`
  }

  // Format price with PKR
  const formatPrice = (price) => {
    return `PKR ${Number(price).toLocaleString()}`
  }

  return (
    <div className="vehicles-page">
      {/* Hero Section */}
      <div className="vehicles-hero">
        <div className="hero-content">
          <h1>🚗 Find Your Perfect Ride</h1>
          <p>Browse our collection of quality vehicles at competitive rates</p>
        </div>
      </div>

      {/* Filters Section */}
      <div className="filters-container">
        <form className="filters" onSubmit={onSubmit}>
          <div className="filter-row">
            <div className="field">
              <label>🚙 Vehicle Type</label>
              <select name="vehicle_type_id" value={filters.vehicle_type_id} onChange={onChange}>
                <option value="">All types</option>
                {vehicleTypes && vehicleTypes.map(t => (
                  <option key={t.vehicle_type_id} value={t.vehicle_type_id}>{t.type_name} ({formatPrice(t.daily_rate)}/day)</option>
                ))}
              </select>
            </div>

            <div className="field">
              <label>📍 Branch</label>
              <select name="branch_id" value={filters.branch_id} onChange={onChange}>
                <option value="">All branches</option>
                {branches && branches.map(b => (
                  <option key={b.branch_id} value={b.branch_id}>{b.branch_name} — {b.city}</option>
                ))}
              </select>
            </div>

            <div className="field">
              <label>📅 Start Date</label>
              <input name="start_date" type="date" value={filters.start_date} onChange={onChange} />
            </div>

            <div className="field">
              <label>📅 End Date</label>
              <input name="end_date" type="date" value={filters.end_date} onChange={onChange} />
            </div>
          </div>

          <div className="actions">
            <button type="submit" className="btn-search" disabled={loading}>
              {loading ? '⏳ Searching...' : '🔍 Search Vehicles'}
            </button>
            <button type="button" className="btn-reset" onClick={reset}>↻ Reset</button>
          </div>
        </form>
      </div>

      {error && <div className="error-message">⚠️ {error}</div>}

      {/* Results Section */}
      <div className="results-section">
        {loading && (
          <div className="loading-state">
            <div className="spinner"></div>
            <p>Finding the best vehicles for you...</p>
          </div>
        )}

        {(!vehicles || vehicles.length === 0) && !loading && (
          <div className="empty-state">
            <div className="empty-icon">🚗</div>
            <h3>No Vehicles Found</h3>
            <p>Try adjusting your filters or check back later for new arrivals.</p>
          </div>
        )}

        <div className="results-grid">
          {vehicles.map(v => (
            <div className="vehicle-card" key={v.vehicle_id} onClick={() => openVehicleModal(v)}>
              <div className="card-image">
                {v.image_url ? (
                  <img src={getImageUrl(v.image_url)} alt={`${v.make} ${v.model}`} onError={(e) => { e.target.style.display = 'none'; e.target.nextSibling.style.display = 'flex' }} />
                ) : null}
                <div className="no-image" style={{display: v.image_url ? 'none' : 'flex'}}>
                  <span className="car-emoji">🚗</span>
                  <span>No Image</span>
                </div>
              </div>
              <div className="card-content">
                <div className="card-header">
                  <h3>{v.make} {v.model}</h3>
                  <span className="vehicle-year">{v.year_made || ''}</span>
                </div>
                <p className="registration">{v.registration_no}</p>
                <div className="card-details">
                  <div className="detail">
                    <span className="label">Type</span>
                    <span className="value">{v.type_name}</span>
                  </div>
                  <div className="detail">
                    <span className="label">Location</span>
                    <span className="value">{v.branch_name}</span>
                  </div>
                </div>
                <div className="card-footer">
                  <div className="price">
                    <span className="amount">{formatPrice(v.daily_rate)}</span>
                    <span className="period">/day</span>
                  </div>
                  <span className={`status-badge ${v.status?.toLowerCase()}`}>{v.status}</span>
                </div>
              </div>
              <div className="card-hover-overlay">
                <span>View Details →</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Vehicle Detail Modal */}
      {selectedVehicle && (
        <div className="modal-overlay" onClick={closeModal}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <button className="modal-close" onClick={closeModal}>×</button>
            
            <div className="modal-image">
              {selectedVehicle.image_url ? (
                <img src={getImageUrl(selectedVehicle.image_url)} alt={`${selectedVehicle.make} ${selectedVehicle.model}`} />
              ) : (
                <div className="no-image">
                  <span className="car-emoji">🚗</span>
                  <span>No Image Available</span>
                </div>
              )}
            </div>

            <div className="modal-body">
              <div className="modal-header">
                <h2>{selectedVehicle.make} {selectedVehicle.model}</h2>
                <p className="modal-reg">{selectedVehicle.registration_no}</p>
              </div>

              <div className="detail-grid">
                <div className="detail-item">
                  <span className="detail-icon">🚙</span>
                  <div>
                    <span className="detail-label">Vehicle Type</span>
                    <span className="detail-value">{selectedVehicle.type_name}</span>
                  </div>
                </div>
                <div className="detail-item">
                  <span className="detail-icon">📅</span>
                  <div>
                    <span className="detail-label">Year</span>
                    <span className="detail-value">{selectedVehicle.year_made || 'N/A'}</span>
                  </div>
                </div>
                <div className="detail-item">
                  <span className="detail-icon">📍</span>
                  <div>
                    <span className="detail-label">Location</span>
                    <span className="detail-value">{selectedVehicle.branch_name}, {selectedVehicle.city}</span>
                  </div>
                </div>
                <div className="detail-item">
                  <span className="detail-icon">✅</span>
                  <div>
                    <span className="detail-label">Status</span>
                    <span className={`status-badge ${selectedVehicle.status?.toLowerCase()}`}>{selectedVehicle.status}</span>
                  </div>
                </div>
              </div>

              {selectedVehicle.type_description && (
                <div className="description-box">
                  <h4>Description</h4>
                  <p>{selectedVehicle.type_description}</p>
                </div>
              )}

              <div className="price-box">
                <div className="price-info">
                  <span className="price-label">Daily Rate</span>
                  <span className="price-amount">{formatPrice(selectedVehicle.daily_rate)}</span>
                </div>
              </div>
            </div>

            <div className="modal-footer">
              <button className="btn-secondary" onClick={closeModal}>Close</button>
              <button className="btn-primary" onClick={handleReserve}>
                {isLoggedIn ? '🚗 Reserve This Vehicle' : '🔐 Login to Reserve'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
