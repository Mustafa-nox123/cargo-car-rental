import React from 'react'
import { Link } from 'react-router-dom'
import './home.css'

export default function Home(){
  return (
    <div className="home-page">
      {/* Hero Section */}
      <section className="hero-section">
        <div className="hero-background"></div>
        <div className="hero-overlay"></div>
        <div className="hero-content">
          <h1>Drive Your Dreams</h1>
          <p>Premium car rental service at affordable prices. Choose from our wide range of vehicles for your next adventure.</p>
          <div className="hero-buttons">
            <Link to="/vehicles" className="btn-primary">
              🚗 Browse Vehicles
            </Link>
            <Link to="/register" className="btn-secondary">
              Create Account
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="features-section">
        <div className="container">
          <h2>Why Choose CarGo?</h2>
          <p className="section-subtitle">We make car rental simple, affordable, and hassle-free</p>
          
          <div className="features-grid">
            <div className="feature-card">
              <div className="feature-icon">🚗</div>
              <h3>Wide Selection</h3>
              <p>Choose from economy cars to luxury vehicles. We have the perfect ride for every occasion.</p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">💰</div>
              <h3>Best Prices</h3>
              <p>Competitive daily rates with no hidden fees. Get the best value for your money.</p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">📍</div>
              <h3>Multiple Locations</h3>
              <p>Pick up and drop off at any of our conveniently located branches across the city.</p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">⚡</div>
              <h3>Easy Booking</h3>
              <p>Book your vehicle in minutes with our simple online reservation system.</p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">🛡️</div>
              <h3>Safe & Reliable</h3>
              <p>All our vehicles are regularly maintained and inspected for your safety.</p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">🎧</div>
              <h3>24/7 Support</h3>
              <p>Our customer support team is always ready to assist you, any time of day.</p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="how-it-works-section">
        <div className="container">
          <h2>How It Works</h2>
          <p className="section-subtitle">Rent a car in 3 simple steps</p>
          
          <div className="steps-grid">
            <div className="step-card">
              <div className="step-number">1</div>
              <h3>Choose Your Vehicle</h3>
              <p>Browse our collection and select the perfect car for your needs</p>
            </div>
            
            <div className="step-connector">→</div>
            
            <div className="step-card">
              <div className="step-number">2</div>
              <h3>Make a Reservation</h3>
              <p>Pick your dates, locations, and complete your booking online</p>
            </div>
            
            <div className="step-connector">→</div>
            
            <div className="step-card">
              <div className="step-number">3</div>
              <h3>Pick Up & Drive</h3>
              <p>Visit our branch, get your keys, and hit the road!</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="cta-section">
        <div className="container">
          <div className="cta-content">
            <h2>Ready to Get Started?</h2>
            <p>Join thousands of satisfied customers who trust CarGo for their car rental needs.</p>
            <div className="cta-buttons">
              <Link to="/vehicles" className="btn-cta-primary">
                View Available Vehicles
              </Link>
              <Link to="/branches" className="btn-cta-secondary">
                Find a Branch Near You
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="home-footer">
        <div className="container">
          <div className="footer-content">
            <div className="footer-brand">
              <div className="footer-logo">
                <span className="logo-car">Car</span>
                <span className="logo-go">Go</span>
              </div>
              <p>Your trusted car rental partner</p>
            </div>
            <div className="footer-links">
              <Link to="/vehicles">Vehicles</Link>
              <Link to="/branches">Branches</Link>
              <Link to="/login">Login</Link>
              <Link to="/register">Register</Link>
            </div>
          </div>
          <div className="footer-bottom">
            <p>© 2024 CarGo. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
