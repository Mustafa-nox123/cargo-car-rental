import React, { useEffect, useState } from 'react'
import { useNavigate, useLocation, Link } from 'react-router-dom'
import api from '../lib/api'
import './dashboard.css'

export default function Dashboard(){
  const [user, setUser] = useState(null)
  const [reservations, setReservations] = useState([])
  const [loading, setLoading] = useState(true)
  const [showAll, setShowAll] = useState(false)
  const location = useLocation()
  const nav = useNavigate()

  useEffect(()=>{
    const t = localStorage.getItem('token')
    const u = localStorage.getItem('user')
    if(!t){
      nav('/login')
      return
    }
    try{
      setUser(u ? JSON.parse(u) : null)
    }catch(e){
      setUser(null)
    }
    
    // Fetch user reservations
    fetchReservations()
  }, [])

  const fetchReservations = async () => {
    try {
      setLoading(true)
      const res = await api.get('/reservations/my')
      setReservations(res.data || [])
    } catch (err) {
      console.error('Failed to fetch reservations:', err)
    } finally {
      setLoading(false)
    }
  }

  const logout = ()=>{
    localStorage.removeItem('token')
    localStorage.removeItem('user')
    try { window.dispatchEvent(new Event('authChanged')) } catch(e){}
    nav('/login')
  }

  const getInitials = (name) => {
    if(!name) return 'US'
    return name.split(' ').map(p=>p[0]).slice(0,2).join('').toUpperCase()
  }

  const formatDate = (dateStr) => {
    if (!dateStr) return 'N/A'
    const date = new Date(dateStr)
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: 'numeric'
    })
  }

  const getStatusClass = (status) => {
    switch(status?.toUpperCase()) {
      case 'BOOKED': return 'status-booked'
      case 'CONVERTED': return 'status-converted'
      case 'COMPLETED': return 'status-completed'
      case 'CANCELLED': return 'status-cancelled'
      default: return 'status-default'
    }
  }

  // Calculate stats
  const totalReservations = reservations.length
  const activeReservations = reservations.filter(r => r.status === 'BOOKED' || r.status === 'CONVERTED').length
  const completedReservations = reservations.filter(r => r.status === 'COMPLETED').length

  // Display reservations (first 5 or all)
  const displayedReservations = showAll ? reservations : reservations.slice(0, 5)

  return (
    <div className="dashboard-page">
      {/* Welcome Banner (only after registration) */}
      {location?.state?.welcome && (
        <div className="welcome-banner-dash">
          <div className="welcome-icon">🎉</div>
          <div className="welcome-content">
            <h2>Welcome to CarGo{user && user.name ? `, ${user.name}` : ''}!</h2>
            <p>Your account was created successfully. Start exploring our vehicles!</p>
          </div>
        </div>
      )}

      {/* Dashboard Header */}
      <div className="dashboard-header">
        <h1>My Dashboard</h1>
        <p>Manage your profile and track your reservations</p>
      </div>

      {/* Dashboard Grid */}
      <div className="dashboard-grid">
        {/* Profile Card */}
        <div className="dashboard-card profile-card">
          <div className="card-header">
            <div className="profile-avatar">
              {getInitials(user?.name)}
            </div>
            <div className="profile-info">
              <h2>{user?.name || 'Customer'}</h2>
              <p>{user?.email || 'No email'}</p>
            </div>
          </div>
          <div className="card-actions">
            <Link to="/vehicles" className="action-btn primary">
              🚗 Browse Vehicles
            </Link>
            <button onClick={logout} className="action-btn danger">
              🚪 Logout
            </button>
          </div>
        </div>

        {/* Stats Card */}
        <div className="dashboard-card stats-card">
          <h3>📊 Your Stats</h3>
          <div className="stats-grid">
            <div className="stat-item">
              <span className="stat-number">{totalReservations}</span>
              <span className="stat-label">Total Bookings</span>
            </div>
            <div className="stat-item">
              <span className="stat-number">{activeReservations}</span>
              <span className="stat-label">Active</span>
            </div>
            <div className="stat-item">
              <span className="stat-number">{completedReservations}</span>
              <span className="stat-label">Completed</span>
            </div>
          </div>
        </div>
      </div>

      {/* Reservation History Card */}
      <div className="dashboard-card reservations-card">
        <div className="reservations-header">
          <h3>📋 Reservation History</h3>
          {reservations.length > 5 && (
            <button 
              className="show-all-btn"
              onClick={() => setShowAll(!showAll)}
            >
              {showAll ? 'Show Less' : `Show All (${reservations.length})`}
            </button>
          )}
        </div>

        {loading ? (
          <div className="loading-state">
            <div className="spinner"></div>
            <p>Loading reservations...</p>
          </div>
        ) : reservations.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">🚗</div>
            <h4>No Reservations Yet</h4>
            <p>You haven't made any reservations. Browse our vehicles and book your first ride!</p>
            <Link to="/vehicles" className="browse-btn">
              Browse Vehicles
            </Link>
          </div>
        ) : (
          <div className="reservations-list">
            {displayedReservations.map((reservation) => (
              <div key={reservation.reservation_id} className="reservation-item">
                <div className="reservation-vehicle">
                  <div className="vehicle-icon">🚗</div>
                  <div className="vehicle-info">
                    <h4>{reservation.vehicle_make} {reservation.vehicle_model}</h4>
                    <p className="reg-number">{reservation.registration_no}</p>
                  </div>
                </div>
                
                <div className="reservation-details">
                  <div className="detail-item">
                    <span className="detail-label">Pickup</span>
                    <span className="detail-value">{formatDate(reservation.start_date)}</span>
                    <span className="branch-name">{reservation.pickup_branch}</span>
                  </div>
                  <div className="detail-arrow">→</div>
                  <div className="detail-item">
                    <span className="detail-label">Return</span>
                    <span className="detail-value">{formatDate(reservation.end_date)}</span>
                    <span className="branch-name">{reservation.dropoff_branch}</span>
                  </div>
                </div>

                <div className="reservation-status">
                  <span className={`status-badge ${getStatusClass(reservation.status)}`}>
                    {reservation.status}
                  </span>
                  <span className="reservation-id">#{reservation.reservation_id}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
