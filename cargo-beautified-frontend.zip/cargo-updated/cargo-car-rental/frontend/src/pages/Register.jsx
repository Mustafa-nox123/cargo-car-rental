import React, { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import api from '../lib/api'
import './auth.css'

export default function Register(){
  const [form, setForm] = useState({
    name:'', email:'', password:'', phone:'', license_no:'', license_expiry:'', address:'', national_id:''
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const nav = useNavigate()

  const onChange = e => {
    const { name, value } = e.target
    setForm(f => ({ ...f, [name]: value }))
  }

  const submit = async e => {
    e.preventDefault()
    setError('')
    if(!form.name || !form.email || !form.password){
      setError('Name, email and password are required')
      return
    }

    setLoading(true)
    try{
      const payload = { ...form }
      // ensure empty strings become null for optional fields if desired
      if(!payload.license_expiry) payload.license_expiry = null

      const res = await api.post('/auth/register', payload)
      const token = res?.data?.token
      if(!token) throw new Error(res?.data?.error || 'No token returned')

      localStorage.setItem('token', token)
      if(res.data.user) localStorage.setItem('user', JSON.stringify(res.data.user))
      // notify other components (Header) about auth update
      try { window.dispatchEvent(new Event('authChanged')) } catch(e){}
      // redirect with a friendly welcome flag
      nav('/dashboard', { state: { welcome: true } })
    }catch(err){
      const msg = err?.response?.data?.error || err?.response?.data?.message || err.message || 'Registration failed'
      setError(msg)
    }finally{
      setLoading(false)
    }
  }

  return (
    <div className="auth-page register-page">
      <div className="auth-background"></div>
      <div className="auth-overlay"></div>
      
      <div className="auth-container">
        <div className="auth-card">
          <div className="auth-header">
            <div className="auth-logo">
              <span className="logo-car">Car</span>
              <span className="logo-go">Go</span>
            </div>
            <h1>Create Account</h1>
            <p>Join CarGo and start renting vehicles today</p>
          </div>

          {error && (
            <div className="auth-error">
              <span>⚠️</span> {error}
            </div>
          )}

          <form className="auth-form" onSubmit={submit}>
            <div className="form-group">
              <label>Full Name *</label>
              <input 
                name="name" 
                value={form.name} 
                onChange={onChange} 
                placeholder="John Doe"
                required 
              />
            </div>

            <div className="form-row">
              <div className="form-group">
                <label>Email *</label>
                <input 
                  name="email" 
                  type="email" 
                  value={form.email} 
                  onChange={onChange} 
                  placeholder="you@example.com"
                  required 
                />
              </div>
              <div className="form-group">
                <label>Password *</label>
                <input 
                  name="password" 
                  type="password" 
                  value={form.password} 
                  onChange={onChange} 
                  placeholder="••••••••"
                  required 
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label>Phone Number</label>
                <input 
                  name="phone" 
                  value={form.phone} 
                  onChange={onChange} 
                  placeholder="+92 300 1234567"
                />
              </div>
              <div className="form-group">
                <label>National ID (CNIC)</label>
                <input 
                  name="national_id" 
                  value={form.national_id} 
                  onChange={onChange} 
                  placeholder="12345-1234567-1"
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label>License Number</label>
                <input 
                  name="license_no" 
                  value={form.license_no} 
                  onChange={onChange} 
                  placeholder="LIC-12345"
                />
              </div>
              <div className="form-group">
                <label>License Expiry</label>
                <input 
                  name="license_expiry" 
                  type="date" 
                  value={form.license_expiry} 
                  onChange={onChange} 
                />
              </div>
            </div>

            <div className="form-group">
              <label>Address</label>
              <textarea 
                name="address" 
                value={form.address} 
                onChange={onChange} 
                placeholder="Your full address"
                rows={2} 
              />
            </div>

            <button type="submit" className="auth-btn" disabled={loading}>
              {loading && <span className="btn-spinner"></span>}
              {loading ? 'Creating Account...' : 'Create Account'}
            </button>

            <p className="terms-text">
              By creating an account, you agree to our Terms of Service and Privacy Policy
            </p>
          </form>

          <div className="auth-footer">
            <p>Already have an account? <Link to="/login">Sign in</Link></p>
          </div>
        </div>
      </div>
    </div>
  )
}
