import React, { useEffect, useState, useRef } from 'react'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import './Header.css'

export default function Header(){
  const [loggedIn, setLoggedIn] = useState(false)
  const [userName, setUserName] = useState(null)
  const [isAdmin, setIsAdmin] = useState(false)
  const navigate = useNavigate()
  const location = useLocation()

  const readUser = () => {
    // prefer explicit user object in localStorage
    const u = localStorage.getItem('user')
    if(u){
      try { const parsed = JSON.parse(u); if(parsed && (parsed.name || parsed.fullname || parsed.email)) return parsed }
      catch(e){}
    }
    // fallback: try to decode user JWT and read a name/email claim
    const t = localStorage.getItem('token')
    if(t){
      try{
        const parts = t.split('.')
        if(parts.length >= 2){
          const payload = parts[1].replace(/-/g, '+').replace(/_/g, '/')
          const json = decodeURIComponent(atob(payload).split('').map(c=> '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2)).join(''))
          const obj = JSON.parse(json)
          return obj
        }
      }catch(e){}
    }
    // if no user token, try admin token
    const at = localStorage.getItem('admin_token')
    if(at){
      try{
        const parts = at.split('.')
        if(parts.length >= 2){
          const payload = parts[1].replace(/-/g, '+').replace(/_/g, '/')
          const json = decodeURIComponent(atob(payload).split('').map(c=> '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2)).join(''))
          const obj = JSON.parse(json)
          return obj
        }
      }catch(e){}
    }
    return null
  }

  const dropdownRef = useRef(null)
  const [open, setOpen] = useState(false)

  useEffect(()=>{
    const update = () => {
      const hasUserToken = !!localStorage.getItem('token')
      const hasAdminToken = !!localStorage.getItem('admin_token')
      const anyLogged = hasUserToken || hasAdminToken
      setLoggedIn(anyLogged)
      setIsAdmin(!!hasAdminToken)
      const u = readUser()
      setUserName(u ? (u.name || u.fullname || u.email) : null)
    }
    update()

    const handler = () => update()
    const onDocClick = e => {
      if(dropdownRef.current && !dropdownRef.current.contains(e.target)) setOpen(false)
    }
    window.addEventListener('authChanged', handler)
    window.addEventListener('adminAuthChanged', handler)
    window.addEventListener('storage', handler)
    document.addEventListener('click', onDocClick)
    return ()=>{
      window.removeEventListener('authChanged', handler)
      window.removeEventListener('adminAuthChanged', handler)
      window.removeEventListener('storage', handler)
      document.removeEventListener('click', onDocClick)
    }
  }, [])

  const logout = ()=>{
    const isAdmin = !!localStorage.getItem('admin_token')
    if(isAdmin){
      localStorage.removeItem('admin_token')
      setLoggedIn(false)
      setUserName(null)
      try { window.dispatchEvent(new Event('adminAuthChanged')) } catch(e){}
      navigate('/admin/login')
    } else {
      localStorage.removeItem('token')
      localStorage.removeItem('user')
      setLoggedIn(false)
      setUserName(null)
      try { window.dispatchEvent(new Event('authChanged')) } catch(e){}
      navigate('/login')
    }
  }

  const initials = (name) => {
    if(!name) return ''
    const parts = name.split(' ').filter(Boolean)
    if(parts.length === 1) return parts[0].slice(0,2).toUpperCase()
    return (parts[0][0] + parts[parts.length-1][0]).toUpperCase()
  }

  const isActive = (path) => {
    return location.pathname === path
  }

  return (
    <header className="site-header">
      <div className="header-container">
        <Link to="/" className="header-logo">
          <span className="logo-car">Car</span>
          <span className="logo-go">Go</span>
        </Link>
        
        <nav className="header-nav">
          <Link to="/branches" className={`nav-link ${isActive('/branches') ? 'active' : ''}`}>
            📍 Branches
          </Link>
          <Link to="/vehicles" className={`nav-link ${isActive('/vehicles') ? 'active' : ''}`}>
            🚗 Vehicles
          </Link>
          
          {loggedIn ? (
            <div className="user-section" ref={dropdownRef}>
              {isAdmin ? (
                <>
                  <Link to="/admin/dashboard" className="nav-link admin-link">
                    ⚙️ Admin
                  </Link>
                  <span className="admin-badge">ADMIN</span>
                </>
              ) : (
                <Link to="/dashboard" className={`nav-link ${isActive('/dashboard') ? 'active' : ''}`}>
                  📊 Dashboard
                </Link>
              )}
              
              <button 
                className="avatar-btn" 
                onClick={() => setOpen(o => !o)} 
                aria-haspopup="true" 
                aria-expanded={open} 
                title={userName || 'Profile'}
              >
                {initials(userName)}
              </button>
              
              {open && (
                <div className="dropdown-menu">
                  <div className="dropdown-header">
                    <span className="dropdown-name">{userName || 'User'}</span>
                    <span className="dropdown-role">{isAdmin ? 'Administrator' : 'Customer'}</span>
                  </div>
                  <div className="dropdown-divider"></div>
                  {isAdmin ? (
                    <>
                      <Link to="/admin/dashboard" className="dropdown-item">
                        ⚙️ Admin Dashboard
                      </Link>
                      <Link to="/dashboard" className="dropdown-item">
                        👤 Profile
                      </Link>
                    </>
                  ) : (
                    <Link to="/dashboard" className="dropdown-item">
                      👤 My Dashboard
                    </Link>
                  )}
                  <div className="dropdown-divider"></div>
                  <button onClick={logout} className="dropdown-item logout">
                    🚪 Logout
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="auth-buttons">
              <Link to="/login" className="btn-login">Sign In</Link>
              <Link to="/register" className="btn-register">Register</Link>
            </div>
          )}
        </nav>
      </div>
    </header>
  )
}
